package com.example.courtvision

class Equipo (
    val nombre: String,
    val division: String,
)
