package com.example.courtvision

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import com.google.firebase.FirebaseApp
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream

class FragmentoAnadirEquipo : Fragment() {

    private val PICK_IMAGE_REQUEST = 1

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?


    ): View? {
        val view = inflater.inflate(R.layout.fragment_fragmento_anadir_equipo, container, false)
        FirebaseApp.initializeApp(requireContext())
        // Botón para seleccionar una imagen
        val btnSeleccionarImagen = view.findViewById<Button>(R.id.BtnSeleccionarImagen)
        btnSeleccionarImagen.setOnClickListener {
            // Lanza la intención para seleccionar una imagen de la galería
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
          startActivityForResult(intent, PICK_IMAGE_REQUEST)
        }

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val buttonVolver = view.findViewById<Button>(R.id.BtnVolverAñadir)

        // Configura el clic del botón de "Volver" para regresar a la lista de equipos
        buttonVolver.setOnClickListener {
            val fragmentManager: FragmentManager = requireActivity().supportFragmentManager
            val transaction = fragmentManager.beginTransaction()
            transaction.replace(R.id.contenedorFragmentos, FragmentoEquipos()) // Reemplaza con tu fragmento de lista de equipos
            transaction.addToBackStack(null)
            transaction.commit()
        }

        val botonAñadirEquipo = view.findViewById<Button>(R.id.BtnEnviarFormularioEquipo)
        botonAñadirEquipo.setOnClickListener {
            // Obtén una referencia a Cloud Firestore
            val db = FirebaseFirestore.getInstance()

            // Obtén los valores de los EditText
            val nombreEquipo = view.findViewById<EditText>(R.id.FormularioNombreEquipo).text.toString()
            val divisionEquipo = view.findViewById<EditText>(R.id.FormularioDivisionEquipo).text.toString()

                // Crea un nuevo documento en la colección "equipos"
                val nuevoEquipoRef = db.collection("equipo").document()

                // Guarda los datos en el documento
                val datosAInsertar: MutableMap<String, Any> = HashMap()
                datosAInsertar["Nombre"] = nombreEquipo
                datosAInsertar["Division"] = divisionEquipo

                nuevoEquipoRef.set(datosAInsertar)
                    .addOnSuccessListener {
                        // Operación exitosa
                        mostrarAlertDialog("Datos agregados correctamente")
                        view.findViewById<EditText>(R.id.FormularioNombreEquipo).setText("")
                        view.findViewById<EditText>(R.id.FormularioNombreEquipo).setText("")
                    }
                    .addOnFailureListener {
                        // Manejar errores
                        mostrarAlertDialog("Error al agregar datos")
                    }
        }
    }

    private fun mostrarAlertDialog(mensaje: String) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setMessage(mensaje)
            .setPositiveButton("Aceptar") { dialog, _ ->
                // Manejar clic en Aceptar si es necesario
                dialog.dismiss()
            }
        val alertDialog = builder.create()
        alertDialog.show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
            // Selecciona la imagen y realiza las operaciones necesarias
            val selectedImageUri = data.data
            // Puedes utilizar la URI de la imagen seleccionada para mostrarla o realizar otras acciones
            val imageView = view?.findViewById<ImageView>(R.id.ImagenFormularioEquipo)
            imageView?.setImageURI(selectedImageUri)
            imageView?.visibility = View.VISIBLE // Muestra la vista previa de la imagen
        }
    }
}