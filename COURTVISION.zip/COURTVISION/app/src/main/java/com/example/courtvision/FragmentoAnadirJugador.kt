package com.example.courtvision

import android.app.AlertDialog
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import com.google.firebase.firestore.FirebaseFirestore

class FragmentoAnadirJugador : Fragment() {



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_fragmento_anadir_jugador, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val botonVolverAñadirJugador = view.findViewById<Button>(R.id.BtnVolverAñadirJugador)
        botonVolverAñadirJugador.setOnClickListener(View.OnClickListener {
            val fragmentManager = requireActivity().supportFragmentManager
            val transaction = fragmentManager.beginTransaction()
            transaction.replace(R.id.contenedorFragmentos, JugadoresFragmento())
            transaction.addToBackStack(null)
            transaction.commit()
        })

        val botonAñadirJugador = view.findViewById<Button>(R.id.BtnEnviarFormularioJugador)
        botonAñadirJugador.setOnClickListener {
            // Obtén una referencia a Cloud Firestore
            val db = FirebaseFirestore.getInstance()

            // Obtén los valores de los EditText
            val nombreJugador = view.findViewById<EditText>(R.id.FormularioNombreJugador).text.toString()
            val dorsalJugador = view.findViewById<EditText>(R.id.FormularioDorsalJugador).text.toString()
            val saludJugador = view.findViewById<EditText>(R.id.FormularioSaludJugador).text.toString()
            val telefonoJugador = view.findViewById<EditText>(R.id.FormularioTelefonoJugador).text.toString()
            val posicionJugador = view.findViewById<EditText>(R.id.FormularioPosicionJugador).text.toString()
            val fechaJugador = view.findViewById<EditText>(R.id.FormularioFechaJugador).text.toString()

            // Crea un nuevo documento en la colección "equipos"
            val nuevoEquipoRef = db.collection("jugador").document()

            // Guarda los datos en el documento
            val datosAInsertar: MutableMap<String, Any> = HashMap()
            datosAInsertar["Nombre"] = nombreJugador
            datosAInsertar["Dorsal"] = dorsalJugador
            datosAInsertar["Salud"] = saludJugador
            datosAInsertar["Telefono"] = telefonoJugador
            datosAInsertar["Posicion"] = posicionJugador
            datosAInsertar["Fecha"] = fechaJugador

            nuevoEquipoRef.set(datosAInsertar)
                .addOnSuccessListener {
                    // Operación exitosa
                    mostrarAlertDialog("Datos agregados correctamente")
                    view.findViewById<EditText>(R.id.FormularioNombreJugador).setText("")
                    view.findViewById<EditText>(R.id.FormularioDorsalJugador).setText("")
                    view.findViewById<EditText>(R.id.FormularioSaludJugador).setText("")
                    view.findViewById<EditText>(R.id.FormularioTelefonoJugador).setText("")
                    view.findViewById<EditText>(R.id.FormularioPosicionJugador).setText("")
                    view.findViewById<EditText>(R.id.FormularioFechaJugador).setText("")
                }
                .addOnFailureListener {
                    // Manejar errores
                    mostrarAlertDialog("Error al agregar datos")
                }
        }
    }
    private fun mostrarAlertDialog(mensaje: String) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setMessage(mensaje)
            .setPositiveButton("Aceptar") { dialog, _ ->
                // Manejar clic en Aceptar si es necesario
                dialog.dismiss()
            }
        val alertDialog = builder.create()
        alertDialog.show()
    }
}