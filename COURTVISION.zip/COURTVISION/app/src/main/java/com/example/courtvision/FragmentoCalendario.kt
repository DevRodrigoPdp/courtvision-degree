package com.example.courtvision

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CalendarView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class FragmentoCalendario : Fragment() {
    private lateinit var calendarView: CalendarView

    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        firebaseAuth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_fragmento_calendario, container, false)
        calendarView = view.findViewById(R.id.calendarioEventos)

        calendarView.setOnDateChangeListener { _, year, month, dayOfMonth ->
            val selectedDate = "$year-${month + 1}-$dayOfMonth"

            // Muestra un Toast con la información del evento desde Firestore
            obtenerInformacionDesdeFirestore(selectedDate)

            // Pasa la fecha seleccionada al FragmentoEventosCalendario
            val fragmentoEventosCalendario = FragmentoEventosCalendario()
            val bundle = Bundle()
            bundle.putString("selectedDate", selectedDate)
            fragmentoEventosCalendario.arguments = bundle

            val transaction = requireActivity().supportFragmentManager.beginTransaction()
            transaction.replace(R.id.contenedorFragmentos, fragmentoEventosCalendario)
            transaction.addToBackStack(null) // Opcional, para habilitar la navegación hacia atrás
            transaction.commit()
        }

        return view
    }

    private fun obtenerInformacionDesdeFirestore(selectedDate: String) {
        val usuarioActual = firebaseAuth.currentUser
        if (usuarioActual != null) {
            val eventosCollection = firestore.collection("eventos")
            eventosCollection
                .whereEqualTo("usuarioId", usuarioActual.uid)
                .whereEqualTo("fecha", selectedDate)
                .get()
                .addOnSuccessListener { documents ->
                    if (!documents.isEmpty) {
                        // Hay eventos para la fecha seleccionada
                        for (document in documents) {
                            val evento = document.data
                            mostrarToastConInformacion(evento)
                        }
                    } else {
                        // No hay eventos para la fecha seleccionada
                        mostrarToastConInformacion(emptyMap())
                    }
                }
                .addOnFailureListener { e ->
                    // Ocurrió un error al obtener eventos desde Firestore
                    mostrarToastConInformacion(emptyMap())
                }
        }
    }

    private fun mostrarToastConInformacion(evento: Map<String, Any>) {
        val titulo = evento["titulo"] as? String ?: ""
        val descripcion = evento["descripcion"] as? String ?: ""
        val ubicacion = evento["ubicacion"] as? String ?: ""
        val hora = evento["hora"] as? String ?: ""

        val mensaje = "Evento:\n" +
                "Título: $titulo\n" +
                "Descripción: $descripcion\n" +
                "Ubicación: $ubicacion\n" +
                "Hora: $hora"

        // Muestra un Toast con la información del formulario desde Firestore
        Toast.makeText(requireContext(), mensaje, Toast.LENGTH_LONG).show()
    }
}
