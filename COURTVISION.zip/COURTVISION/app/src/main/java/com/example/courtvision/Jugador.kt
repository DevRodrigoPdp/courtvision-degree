package com.example.courtvision

import java.util.Date

class Jugador (
    val nombreJugador: String,
    val dorsalJugador: Int,
    val estadoSaludJugador: String,
    val telefonoJugador: Int,
    val posicionJugador: String,
    val fechaNacimiento: Date
)